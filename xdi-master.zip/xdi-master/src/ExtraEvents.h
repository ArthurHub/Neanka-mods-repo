#pragma once

struct MenuOpenCloseEventEx
{
    BSFixedString menuName;
    bool opening;
};